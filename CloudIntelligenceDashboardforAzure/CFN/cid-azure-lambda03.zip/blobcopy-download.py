import json
import os
import re
from urllib import parse
from boto3 import client as Client
from azure.identity import ClientAssertionCredential, ClientSecretCredential
from azure.storage.blob import BlobServiceClient

# Microsoft Entra ID authentication. "ClientSecret" (default) uses the app registration client secret.
# "FederatedIdentity" uses no secret: the Lambda execution role gets a short-lived JWT from AWS STS
# (IAM outbound identity federation) and Entra ID trusts it through a federated identity credential.
FEDERATION_AUDIENCE = 'api://AzureADTokenExchange'

def get_azure_credential(tenant_id, application_id, application_secret, auth_method='ClientSecret'):
    if auth_method == 'FederatedIdentity':
        sts = Client('sts')

        def get_assertion():
            return sts.get_web_identity_token(
                Audience=[FEDERATION_AUDIENCE],
                SigningAlgorithm='RS256',
                DurationSeconds=300
            )['WebIdentityToken']

        return ClientAssertionCredential(tenant_id, application_id, get_assertion)
    return ClientSecretCredential(tenant_id, application_id, application_secret)

# Azure Blob Copy function to retrieve the blob file via info from the SNS topic
# New secure token created for the Azure connection to avoid connection noise and enable distinct blob downloads
def lambda_handler(event, context):

    response = event['Records'][0]['Sns'].get('Message','not found')
    # The initial json loaded into values is the BlobInfo object
    # BlobInfo contains the values payload as a property, loading that separately as valuePayload
    values = json.loads(response)
    
    valuePayload = json.loads(json.dumps(values['valuePayload']))
    # accountName = valuePayload.get('account_name','nameNotFound')
    active_directory_tenant_id = valuePayload.get('tenantid','notFound')
    active_directory_application_id = valuePayload.get('appid','notFound') 
    active_directory_application_secret = valuePayload.get('appsecret','notFound')
    active_directory_auth_method = valuePayload.get('authmethod','ClientSecret')
    oauth_url = valuePayload.get('oauth_url','urlNotFound')
    
    bucket_name = valuePayload.get('bucket_name','bucketNotFound')
    containerName = values.get("container","notFound")
    blobName = values.get("blob","notFound")
    fileName = values.get("fileName","notFound")
    # TODO: if blobSize > someArbituary value: increase lambda specs or perform partition download
    blobSize = values.get("size","notFound")
    blobLastModified = values.get("lastmodified","1900-01-01 00:00:00")
    blobKey = values.get('fullFilePath',''+'/'+fileName)
    token_credential = get_azure_credential(
        active_directory_tenant_id,
        active_directory_application_id,
        active_directory_application_secret,
        active_directory_auth_method
    )
    blob_service_client = BlobServiceClient(
        account_url=oauth_url, 
        credential=token_credential
    )

    # Blob_client to directly retrieves the blob from the specified container
    blob_client = blob_service_client.get_blob_client(container=containerName, blob=blobName)
    os.chdir('/tmp')

    # Upload the file to the user specified S3 bucket
    with open(fileName, "wb") as my_blob:
        download_stream = blob_client.download_blob()
        my_blob.write(download_stream.readall())
        s3 = Client('s3')
        tags = {"container": containerName,"blobname": re.sub("[^\w.:+=@_/-]", "-",blobName),"size": blobSize, "lastmodified": blobLastModified}

        s3.upload_file(
            Filename = fileName,
            Bucket =  bucket_name,
            Key = blobKey,
            ExtraArgs = {"Tagging": parse.urlencode(tags)}
            )
       
    
    return {
        'statusCode': 200,
        'body': json.dumps(response)
    }
