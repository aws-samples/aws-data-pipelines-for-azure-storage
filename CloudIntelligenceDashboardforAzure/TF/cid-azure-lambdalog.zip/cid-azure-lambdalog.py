import os
import json
import uuid
import urllib3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

http = urllib3.PoolManager()
endpoint = os.environ["API_ENDPOINT"]
account_id = os.environ.get("account_id")
dashboard_id = os.environ.get("dashboard_id")

def execute_request(action, product_id, via_key):
    payload = {'dashboard_id': product_id, 'account_id': account_id, via_key: 'Terraform'}
    logger.info(f"Sending payload: {json.dumps(payload)}")
    
    try:
        encoded_data = json.dumps(payload).encode('utf-8')
        r = http.request(action, endpoint, body=encoded_data, headers={'Content-Type': 'application/json'})
        if r.status != 200:
            logger.error(f"API call {action} returned {r.status}: {r.data.decode('utf-8')}")
            return False, f"Issue logging action {action} for dashboard {product_id} and account {account_id}. Status: {r.status}, Response: {r.data.decode('utf-8')}"
    except urllib3.exceptions.HTTPError as e:
        logger.error(f"HTTPError: {str(e)}")
        return False, f"Issue logging action {action} for dashboard {product_id} and account {account_id} due to {str(e)}"
    
    return True, None

def lambda_handler(event, context):
    logger.info(f"Event received: {json.dumps(event)}")

    res, reason = execute_request('PUT', dashboard_id, 'created_via')
    
    if not res:
        logger.error(f"Failed to log installation: {reason}")
        return {
            'statusCode': 500,
            'body': json.dumps({"message": reason})
        }

    logger.info(f"Installation log successfully created for {dashboard_id}")
    return {
        'statusCode': 200,
        'body': json.dumps({"message": "Success"})
    }